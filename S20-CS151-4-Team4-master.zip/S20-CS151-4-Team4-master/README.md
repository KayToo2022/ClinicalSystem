# S20-CS151-4-Team4
CS151 Team Project, Clinical information system

### Contribution 
Steven Chang: Helped with use case analysis, Use case diagram, UI design, set up github<br />
Kyle Tu: JavaDoc, helped with use case analysis and class diagram<br />
Tom Mach: Class Diagram, Sequence Diagrams, State Diagram<br />
