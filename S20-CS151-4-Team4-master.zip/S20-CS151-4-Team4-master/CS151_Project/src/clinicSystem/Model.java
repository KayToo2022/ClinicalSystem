package clinicSystem;

import java.util.ArrayList;

/**
 * A class representing the clinic's database
 * 
 * @author ktu20
 *
 */
public class Model {

	public int patientIndex;
	public Patient currentPatient;
	public int visitIndex;
	public Visit currentVisit;
	
	private ArrayList<Patient> listOfPatients = new ArrayList<Patient>();

	/**
	 * an arraylist of visits happening in the future
	 */
	private ArrayList<Visit> visitScheduled;

	/**
	 * takes a patient and registers them into the database
	 * 
	 * @param patient a patient to be added
	 */
	public void registerNewPatient(Patient patient) {
		listOfPatients.add(patient);
	}

	public ArrayList<Patient> getListOfPatients() {
		return listOfPatients;
	}

	public void setListOfPatients(ArrayList<Patient> listOfPatients) {
		this.listOfPatients = listOfPatients;
	}

	public ArrayList<Visit> getVisitScheduled() {
		return visitScheduled;
	}

	public void setVisitScheduled(ArrayList<Visit> visitScheduled) {
		this.visitScheduled = visitScheduled;
	}


	/**
	 * returns the full list of visits
	 * 
	 * @return all visits at the clinic
	 */
	private ArrayList<Visit> viewVisitHistory(Patient p) {
		return p.getVisits();
	}
	
	public void addVisit(Visit v, Patient p) {
		p.addVisit(v);
	}

	/**
	 * allows the system to assign a certain category to a patient
	 * 
	 * @param patient  a patient to assign a category to
	 * @param category the number category they are in
	 */
	
	private void assignCategory(Patient patient, String category) {
		patient.setCategory(category);
	}

	/**
	 * allows the system to assign a certain protocol to a patient
	 * 
	 * @param patient a patient to assign a protocol to
	 * @param protcol the number protocol they are in
	 */
	private void assignProtocol(Patient patient, String protcol) {
		patient.setProtocol(protcol);
	}


	

	/**
	 * Allows the sytem to search for a specific visit based on the patient and the
	 * visit number
	 * 
	 * @param patient  the patient
	 * @param visitNum the visit of that patient
	 * @return the desired visit
	 */
	private Visit searchVisit(Patient patient, int visitNum) {
		for(Visit v : patient.getVisits()) {
			if (patient.getVisit(v.getVisitNum()) == patient.getVisit(visitNum)) {
				return v;
			}
		}
		return null;
	}
	
	public Patient searchPatientID(String ID) {
		for (Patient p : listOfPatients) {
			if (ID.contentEquals(p.getID()))
				return p;
		}
		return null;
	}
	
	public int searchPatientIDIndex(String ID) {
		int index = 0;
		for (Patient p : listOfPatients) {
			if (ID.contentEquals(p.getID()))
				return index;
			index++;
		}
		return -1;
	}
	
	public void setCurrentPatientIndex(String ID) {
		patientIndex = searchPatientIDIndex(ID);
	}
	
	public void setCurrentPatient(String ID) {
		currentPatient = searchPatientID(ID);
	}
	
	public int searchVisitSequenceIndex(String i) {
		int index = 0;
		for (Visit v : currentPatient.getListOfVisits()) {
			if (Integer.parseInt(i)==v.getVisitNum())
				return index;
			index++;
		}
		return -1;
	}
	
	public Visit searchVisitSequence(String i) {
		for (Visit v : currentPatient.getListOfVisits()) {
			if (Integer.parseInt(i)==v.getVisitNum())
				return v;
		}
		return null;
	}
	
	public void setCurrentVisitIndex(String ID) {
		visitIndex = searchVisitSequenceIndex(ID);
	}
	
	public void setCurrentVisit(String ID) {
		currentVisit = searchVisitSequence(ID);
	}
	
}
