package clinicSystem;

public class App {

	public static void main(String[] args) {
		Model model = new Model();
		Controller control = new Controller(model);		
	}
}
