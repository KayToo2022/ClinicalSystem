package clinicSystem;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.*;

public class NewPatientView extends View {
	
	private JPanel newPatientPanel;
	
	private JPanel northPanel = new JPanel();
	private JLabel titleLabel = new JLabel("Register New Patient");
	
	private JPanel leftPanel = new JPanel();
	private JLabel idLabel = new JLabel("Identification Number");
	private JTextField id = new JTextField("ID #");
	private JLabel dateLabel = new JLabel("Todays Date");
	private JTextField dateField = new JTextField("Date");
	private JLabel dobLabel = new JLabel("Birth Date");
	private JTextField dobField = new JTextField("DOB");
	private JLabel genderLabel = new JLabel("Gender");
	private JTextField genderField = new JTextField("Male/Female");
	private JLabel nameLabel = new JLabel("Name");
	private JTextField firstNameText = new JTextField("First");
	private JTextField lastNameText = new JTextField("Last");
	private JLabel phoneLabel = new JLabel("Phone Number");
	private JTextField phoneField = new JTextField("#");
	private JLabel ssnLabel = new JLabel("Social Security Number");
	private JTextField ssnField = new JTextField("SSN");
	private JLabel insuranceLabel = new JLabel("Insurance Number");
	private JTextField insuranceField = new JTextField("Insurance #");
	
	private JPanel centerPanel = new JPanel();

	private JPanel rightPanel = new JPanel();
	private JLabel address1Label = new JLabel("Street Address");
	private JTextField address1Field = new JTextField("Address #1");
	private JLabel address2Label = new JLabel("Street Address #2");
	private JTextField address2Field = new JTextField("Address #2");
	private JLabel cityLabel = new JLabel("City");
	private JTextField cityField = new JTextField("City");
	private JLabel stateLabel = new JLabel("State");
	private JTextField stateField = new JTextField("State");
	private JLabel zipLabel = new JLabel("Postal/Zip");
	private JTextField zipField = new JTextField("Zip");
	private JLabel addInfoLabel = new JLabel("Additional Information");
	private JTextArea addInfoArea = new JTextArea("Additional Information");

	private JPanel bottomPanel = new JPanel();
	private JLabel medicalNotesLabel = new JLabel("Medical Notes");
	private JTextArea medicalNotes = new JTextArea("Etiology and Onset, medical notes, ect.");
	private JButton saveBtn = new JButton("Save");
	private JButton cancelBtn = new JButton("Cancel");
	
	/**
	 * Constructor for NewPatientView.
	 */
	public NewPatientView() {
		super();
		newPatientPanel = new JPanel();
		newPatientPanel.setLayout(new BorderLayout());
		
		addNorthPanel();
		addLeftPanel();
		addCenterPanel();
		addRightPanel();
		addBottomPanel();
		this.add(newPatientPanel);
	}
	
	/**
	 * Creates North Panel and adds it to the NewPatientView panel.
	 */
	private void addNorthPanel() {
		titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
		northPanel.setPreferredSize(new Dimension(1000, 50));
		northPanel.setLayout(new BorderLayout());
		northPanel.add(titleLabel, BorderLayout.WEST);
		newPatientPanel.add(northPanel, BorderLayout.NORTH);
	}
	
	/**
	 * Creates Left Panel and adds it to the NewPatientView panel.
	 */
	private void addLeftPanel() {
		leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.PAGE_AXIS));
		leftPanel.setPreferredSize(new Dimension(450, 350));
		
		leftPanel.add(nameLabel);
		leftPanel.add(firstNameText);
		leftPanel.add(lastNameText);
		leftPanel.add(idLabel);
		leftPanel.add(id);
		leftPanel.add(dobLabel);
		leftPanel.add(dobField);
		leftPanel.add(genderLabel);
		leftPanel.add(genderField);
		leftPanel.add(dateLabel);
		leftPanel.add(dateField);
		leftPanel.add(phoneLabel);
		leftPanel.add(phoneField);
		leftPanel.add(ssnLabel);
		leftPanel.add(ssnField);
		leftPanel.add(insuranceLabel);
		leftPanel.add(insuranceField);
		
		newPatientPanel.add(leftPanel, BorderLayout.WEST);

	}
	
	/**
	 * Creates Center Panel and adds it to the NewPatientView panel.
	 */
	private void addCenterPanel() {
		newPatientPanel.add(centerPanel);
		centerPanel.setPreferredSize(new Dimension(100, 350));
		
	}
	
	/**
	 * Creates Right Panel and adds it to the NewPatientView panel.
	 */
	private void addRightPanel() {
		rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.PAGE_AXIS));
		rightPanel.setPreferredSize(new Dimension(450, 350));
		
		rightPanel.add(address1Label);
		rightPanel.add(medicalNotesLabel);
		rightPanel.add(address1Field);
		rightPanel.add(address2Label);
		rightPanel.add(address2Field);
		rightPanel.add(cityLabel);
		rightPanel.add(cityField);
		rightPanel.add(stateLabel);
		rightPanel.add(stateField);
		rightPanel.add(zipLabel);
		rightPanel.add(zipField);
		rightPanel.add(addInfoLabel);
		
		JScrollPane addInfoScrollPane = new JScrollPane(addInfoArea);
		addInfoScrollPane.setPreferredSize(new Dimension(450, 100));
		rightPanel.add(addInfoScrollPane);

		
		newPatientPanel.add(rightPanel, BorderLayout.EAST);

	}
	
	/**
	 * Creates Bottom Panel and adds it to the NewPatientView panel.
	 */
	private void addBottomPanel() {
		bottomPanel.setLayout(new BorderLayout());
		bottomPanel.setPreferredSize(new Dimension(1000, 200));
		bottomPanel.add(medicalNotesLabel, BorderLayout.NORTH);
		JScrollPane medNotesScrollPane = new JScrollPane(medicalNotes);
		bottomPanel.add(medNotesScrollPane, BorderLayout.CENTER);
		
		JPanel buttonPanel =  new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		buttonPanel.add(saveBtn);
		buttonPanel.add(cancelBtn);
		
		bottomPanel.add(buttonPanel, BorderLayout.SOUTH);
		
		newPatientPanel.add(bottomPanel, BorderLayout.SOUTH);
	}
	
	/**
	 * Refreshes NewPatientView so old user entered values don't remain.
	 */
	public void refreshView() {
		id.setText("ID #");
		dateField.setText("Date");
		dobField.setText("DOB");
		genderField.setText("Male/Female");
		firstNameText.setText("First");
		lastNameText.setText("Last");
		phoneField.setText("#");
		ssnField.setText("SSN");
		insuranceField.setText("Insurance #");
		address1Field.setText("Address #1");
		address2Field.setText("Address #2");
		cityField.setText("City");
		stateField.setText("State");
		zipField.setText("Zip");
		addInfoArea.setText("Additional Information");
		medicalNotes.setText("Etiology and Onset, medical notes, ect.");
	}
	
	/**
	 * Adds action listener to the save button.
	 * 
	 * @param listenForSaveBtn - Action Listener containing the save button functionality. 
	 */
	public void newPatientSaveListener(ActionListener listenForSaveBtn) {
		saveBtn.addActionListener(listenForSaveBtn);
	}
	
	/**
	 * Adds action Listener to the cancel button.
	 * 
	 * @param listenForCancelBtn - Action Listener containing the cancel button functionality.
	 */
	public void newPatientCancelListener(ActionListener listenForCancelBtn) {
		cancelBtn.addActionListener(listenForCancelBtn);
	}

	/**
	 * Getters for data.
	 * 
	 * @return data value.
	 */
	
	public String getIdField() {
		return id.getText();
	}

	public String getDateField() {
		return dateField.getText();
	}
	
	public String getDobField() {
		return dobField.getText();
	}
	
	public String getGenderField() {
		return genderField.getText();
	}

	public String getFirstNameText() {
		return firstNameText.getText();
	}

	public String getLastNameText() {
		return lastNameText.getText();
	}

	public String getPhoneField() {
		return phoneField.getText();
	}

	public String getSsnField() {
		return ssnField.getText();
	}

	public String getInsuranceField() {
		return insuranceField.getText();
	}

	public String getAddress1Field() {
		return address1Field.getText();
	}

	public String getAddress2Field() {
		return address2Field.getText();
	}

	public String getCityField() {
		return cityField.getText();
	}

	public String getStateField() {
		return stateField.getText();
	}

	public String getZipField() {
		return zipField.getText();
	}

	public String getAddInfoArea() {
		return addInfoArea.getText();
	}

	public String getMedicalNotes() {
		return medicalNotes.getText();
	}
}
