package clinicSystem;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class HomeView extends View {
	
	private JPanel homePanel;
	
	//North Panel Components
	private JPanel northPanel;
	private JLabel titleLabel;
	private JPanel registerPatientPanel;
	private JButton registerPatient;
	
	//Center Panel Components
	private JPanel centerPanel;
	private JTable table;
	private DefaultTableModel tableModel;
	private JScrollPane sp;
	
	//South Panel Components
	private JPanel southPanel;
	private JLabel searchName;
	private JPanel searchBarPanel;
	private JTextField searchBar;
	private JPanel searchButtonPanel;
	private JButton searchButton;
	
	HomeView(){
		super();
		this.setVisible(true);
		homePanel = new JPanel();
		homePanel.setLayout(new BorderLayout());
		addNorthPanel();
		addCenterPanel();
		addSouthPanel();
		
		this.add(homePanel);
	}
	
	//Adds the Title, and register new patient button to the top of the frame
	public void addNorthPanel() {
		northPanel = new JPanel();
		northPanel.setPreferredSize(new Dimension(1000, 50));
		northPanel.setLayout(new BorderLayout());
		
		titleLabel = new JLabel("Home");
		titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
		
		registerPatientPanel = new JPanel();
		registerPatient = new JButton("Register New Patient");
		registerPatient.setPreferredSize(new Dimension(200, 10));
		registerPatientPanel.add(registerPatient);
		northPanel.add(titleLabel, BorderLayout.WEST);
		northPanel.add(registerPatient, BorderLayout.EAST);
		homePanel.add(northPanel, BorderLayout.NORTH);
	}
	
	//Adds the Table to the center of the Frame
	public void addCenterPanel() {
		centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
		
		tableModel = new DefaultTableModel();
		tableModel.addColumn("Name");
		tableModel.addColumn("ID #");
		tableModel.addColumn("Address");
		tableModel.addColumn("Age");
		tableModel.addColumn("Gender");

		table = new JTable(tableModel);
		sp = new JScrollPane(table);
		centerPanel.add(sp);
		
		homePanel.add(centerPanel, BorderLayout.CENTER);
	}
	
	//Adds the search Bar to the bottom of the frame
	public void addSouthPanel() {
		southPanel = new JPanel();
		
		southPanel.setPreferredSize(new Dimension(1000, 50));
		southPanel.setLayout(new BorderLayout());
		
		searchName = new JLabel("Enter Patient ID: ");
		searchBarPanel = new JPanel();
		searchBar = new JTextField("ID #");
		searchBar.setPreferredSize(new Dimension(750, 20));
		searchBarPanel.add(searchName);
		searchBarPanel.add(searchBar);
		searchButtonPanel = new JPanel();
		searchButton = new JButton("Enter");
		searchButton.setPreferredSize(new Dimension(100, 20));
		searchButtonPanel.add(searchButton);
		
		southPanel.add(searchBarPanel, BorderLayout.WEST);
		southPanel.add(searchButtonPanel, BorderLayout.EAST);
		
		homePanel.add(southPanel, BorderLayout.SOUTH);
	}
	
	//Adds and action Listener to the Register New Patient Button
	public void newPatientRegisterListener(ActionListener listenForRegisterBtn) {
		registerPatient.addActionListener(listenForRegisterBtn);
	}
	
	//Adds an action Listener to the Enter Search Button
	public void homeSelectPatientListener(ActionListener listenForSearchBtn) {
		searchButton.addActionListener(listenForSearchBtn);
	}
	
	//Returns the text inside the search bar
	public String getSearchBarText() {
		return this.searchBar.getText();
	}
	
	//Returns the number of rows/Patients in the Patient Table
	public int getTableSize() {
		return tableModel.getRowCount();
	}
	
	//Adds a Patients Info to the Patient Table
	public void addPatient(String[] patient) {
		tableModel.insertRow(tableModel.getRowCount(), patient);
	}
	
	//Updates the Patients Information displayed in the Table
	public void updatePatient(String[] patient, int tableIndex) {
		tableModel.insertRow(tableIndex, patient);
		tableModel.removeRow(tableIndex + 1);

	}
}
