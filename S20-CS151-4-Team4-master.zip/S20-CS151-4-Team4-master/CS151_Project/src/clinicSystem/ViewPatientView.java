package clinicSystem;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ViewPatientView extends View {
	
	private JPanel viewPatientPanel;
	private Patient current = new Patient("Apple", "Sauce"); // Displays Patient's information
	
	private JPanel northPanel;
	private JPanel titlePanel;
	private JLabel titleLabel;
	private JButton home;
	private JButton editBtn;
	private JPanel northWestPanel;
	private JLabel idLabel;
	private JTextField id;
	private JLabel dobLabel;
	private JTextField dob;
	private JLabel genderLabel;
	private JTextField gender;
	private JLabel phoneNumLabel;
	private JTextField phoneNum;
	private JPanel northEastPanel;
	private JLabel addressLabel;
	private JTextField address;
	private JTextField cityStateZip;
	private JLabel ssnLabel;
	private JTextField ssn;
	private JLabel insuranceLabel;
	private JTextField insurance;
	private JLabel categoryLabel;
	private JTextField category;
	
	private JPanel southPanel;
	private JPanel topSouthPanel;
	private JButton addVisitBtn;
	private JLabel chartLabel = new JLabel("Visits");
	private JTable table;
	private DefaultTableModel tableModel;
	private JScrollPane sp;
	
	private JPanel bottomPanel;
	private JLabel searchName;
	private JPanel searchBarPanel;
	private JTextField searchBar;
	private JPanel searchButtonPanel;
	private JButton searchButton;
	
	/**
	 * Constructor for ViewPatientView.
	 */
	public ViewPatientView() {
		super();
		this.setVisible(true);
		viewPatientPanel = new JPanel();
		viewPatientPanel.setLayout(new BorderLayout());
		addNorthPanel();
		addSouthPanel();
		
		this.add(viewPatientPanel);
	}
	
	/**
	 * Creates North Panel and adds it to the ViewPatientView panel.
	 */
	public void addNorthPanel() {
		northPanel = new JPanel();
		northPanel.setPreferredSize(new Dimension(1000, 500));
		northPanel.setLayout(new BorderLayout());
		
		titlePanel = new JPanel();
		titlePanel.setLayout(new FlowLayout());
		titleLabel = new JLabel("Patient " + current.getFirstName() + " " + current.getLastName());
		titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
		titleLabel.setPreferredSize(new Dimension(800, 30));
		home = new JButton("Home");
		editBtn = new JButton("Edit");
		titlePanel.add(titleLabel);
		titlePanel.add(home);
		titlePanel.add(editBtn);
		northPanel.add(titlePanel, BorderLayout.NORTH);
		
		northWestPanel = new JPanel();
		northWestPanel.setLayout(new BoxLayout(northWestPanel, BoxLayout.PAGE_AXIS));
		northWestPanel.setPreferredSize(new Dimension(450, 100));
		
		idLabel = new JLabel("Identification Number");
		id = new JTextField();
		id.setEditable(false);
		dobLabel = new JLabel("Date of Birth");
		dob = new JTextField();
		dob.setEditable(false);
		genderLabel = new JLabel("Gender");
		gender = new JTextField();
		gender.setEditable(false);
		phoneNumLabel = new JLabel("Phone Number");
		phoneNum = new JTextField();
		phoneNum.setEditable(false);
		
		northWestPanel.add(idLabel);
		northWestPanel.add(id);
		northWestPanel.add(dobLabel);
		northWestPanel.add(dob);
		northWestPanel.add(genderLabel);
		northWestPanel.add(gender);
		northWestPanel.add(phoneNumLabel);
		northWestPanel.add(phoneNum);
		
		northEastPanel = new JPanel();
		northEastPanel.setLayout(new BoxLayout(northEastPanel, BoxLayout.PAGE_AXIS));
		northEastPanel.setPreferredSize(new Dimension(450, 100));
		
		addressLabel = new JLabel("Address");
		address = new JTextField();
		address.setEditable(false);
		cityStateZip = new JTextField();
		cityStateZip.setEditable(false);
		ssnLabel = new JLabel("Social Security Number");
		ssn = new JTextField();
		ssn.setEditable(false);
		insuranceLabel = new JLabel("Insurance Number");
		insurance = new JTextField();
		insurance.setEditable(false);
		categoryLabel = new JLabel("Category");
		category = new JTextField();
		category.setEditable(false);
		
		northEastPanel.add(addressLabel);
		northEastPanel.add(address);
		northEastPanel.add(cityStateZip);
		northEastPanel.add(ssnLabel);
		northEastPanel.add(ssn);
		northEastPanel.add(insuranceLabel);
		northEastPanel.add(insurance);
		northEastPanel.add(categoryLabel);
		northEastPanel.add(category);
		
		northPanel.add(northWestPanel, BorderLayout.WEST);
		northPanel.add(northEastPanel, BorderLayout.EAST);
		
		viewPatientPanel.add(northPanel);
	}
	
	/**
	 * Creates South Panel and adds it to the ViewPatientView panel.
	 */
	public void addSouthPanel() {
		southPanel = new JPanel();
		southPanel.setPreferredSize(new Dimension(1000, 500));
		southPanel.setLayout(new BorderLayout());

		topSouthPanel = new JPanel();
		addVisitBtn = new JButton("Add Visit");
		chartLabel = new JLabel("Visits");
		chartLabel.setPreferredSize(new Dimension(800, 30));
		chartLabel.setFont(new Font("Serif", Font.BOLD, 24));
		
		topSouthPanel.add(chartLabel);
		topSouthPanel.add(addVisitBtn);
		southPanel.add(topSouthPanel, BorderLayout.NORTH);
		
		tableModel = new DefaultTableModel();
		tableModel.addColumn("Visit #");
		tableModel.addColumn("Date");
		tableModel.addColumn("Sound Generator");
		tableModel.addColumn("Hearing Aid");
		tableModel.addColumn("Combined Instruments");
		tableModel.addColumn("Ear Measurements");
		
		table = new JTable(tableModel);
		sp = new JScrollPane(table);
		
		southPanel.add(sp, BorderLayout.CENTER);
		
		bottomPanel = new JPanel();
		
		bottomPanel.setPreferredSize(new Dimension(1000, 50));
		bottomPanel.setLayout(new BorderLayout());
		
		searchName = new JLabel("View/Edit Visit: ");
		searchBarPanel = new JPanel();
		searchBar = new JTextField("Enter Visit #");
		searchBar.setPreferredSize(new Dimension(750, 20));
		searchBarPanel.add(searchName);
		searchBarPanel.add(searchBar);
		
		searchButtonPanel = new JPanel();
		searchButton = new JButton("Enter");
		searchButton.setPreferredSize(new Dimension(100, 20));
		searchButtonPanel.add(searchButton);
		
		bottomPanel.add(searchBarPanel, BorderLayout.WEST);
		bottomPanel.add(searchButtonPanel, BorderLayout.EAST);
		
		southPanel.add(bottomPanel, BorderLayout.SOUTH);
		
		viewPatientPanel.add(southPanel, BorderLayout.SOUTH);
	}
	
	/**
	 * Adds Action Listener to Home Button.
	 * 
	 * @param listenForSaveBtn - Action Listener containing the home button functionality. 
	 */
	public void viewPatientHomeListener(ActionListener listenForHomeBtn) {
		home.addActionListener(listenForHomeBtn);
	}
	
	/**
	 * Adds Action Listener to Edit Button.
	 * 
	 * @param listenForEditBtn - Action Listener containing the edit button functionality. 
	 */
	public void viewPatientEditListener(ActionListener listenForEditBtn) {
		editBtn.addActionListener(listenForEditBtn);
	}
	
	/**
	 * Adds Action Listener to Add Visit Button.
	 * 
	 * @param listenForAddVisitBtn - Action Listener containing the add visit button functionality. 
	 */
	public void viewPatientAddVisitListener(ActionListener listenForAddVisitBtn) {
		addVisitBtn.addActionListener(listenForAddVisitBtn);
	}
	
	/**
	 * Adds Action Listener to Select Visit Button.
	 * 
	 * @param listenForSelectVisitBtn - Action Listener containing the select visit button functionality. 
	 */
	public void viewPatientSelectVisitListener(ActionListener listenForSelectVisitBtn) {
		searchButton.addActionListener(listenForSelectVisitBtn);
	}
	
	/**
	 * Draws the table.
	 * 
	 * @param visitsInfo - all the data for the patient's visit.
	 */
	public void drawTable(String[][] visitsInfo) {
		clearTable();
		for(int i = 0; i< visitsInfo.length; i++) {
			tableModel.addRow(visitsInfo[i]);
		}
	}
	
	/**
	 * Clears the data table.
	 */
	public void clearTable() {
		int rows = tableModel.getRowCount(); 
		for(int i = rows - 1; i >=0; i--)
		{
			tableModel.removeRow(i); 
		}
	}
	
	/**
	 * Get table size.
	 * 
	 * @return number of rows.
	 */
	public int getTableSize() {
		return tableModel.getRowCount();
	}
	
	/**
	 * Get search bar field text.
	 * 
	 * @return search bar field text.
	 */
	public int getSearchBarField() {
		return Integer.parseInt(searchBar.getText());
	}
	
	/**
	 * Setters for data values.
	 * 
	 * @param T data - replaces this data with new data.
	 */
	
	public void setID(String id) {
		this.id.setText(id);
	}
	
	public void setDOB(String dob) {
		this.dob.setText(dob);
	}
	
	public void setGender(String gender) {
		this.gender.setText(gender);
	}
	
	public void setPhoneNum(String PhoneNum) {
		this.phoneNum.setText(PhoneNum);
	}
	
	public void setAddress(String address) {
		this.address.setText(address);
	}
	
	public void setCityStateZip(String cityStateZip) { 
		this.cityStateZip.setText(cityStateZip);
	}
	
	public void setSSN(String ssn) {
		this.ssn.setText(ssn);
	}
	
	public void setInsurance(String insurance) {
		this.insurance.setText(insurance);
	}
	
	public void setCategory(String category) {
		this.category.setText(category);
	}
	
	public void setTitleLabel(String s) {
		this.titleLabel.setText(s);
	}
}
