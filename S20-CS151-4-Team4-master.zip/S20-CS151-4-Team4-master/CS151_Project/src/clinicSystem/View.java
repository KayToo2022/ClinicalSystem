package clinicSystem;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * A class that will update what the employee sees
 * 
 * @author ktu20
 *
 */
public class View extends JFrame{
	View(){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setSize(1000, 800);
	}
	
	void displayErrorMessage(String errorMessage) {
		JOptionPane.showMessageDialog(this, errorMessage);
	}
}
