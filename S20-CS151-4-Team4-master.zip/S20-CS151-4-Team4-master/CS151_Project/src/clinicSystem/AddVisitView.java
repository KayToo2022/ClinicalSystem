package clinicSystem;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class AddVisitView extends View {
	private JPanel newVisitPanel;

	private JPanel northPanel = new JPanel();
	private JLabel titleLabel = new JLabel("Add Visit");

	private JPanel leftPanel = new JPanel();
	private JLabel soundGeneratorLabel = new JLabel("Sound Generator");
	private JLabel viennatoneLabel = new JLabel("Viennatone");
	private JCheckBox amtiCheck = new JCheckBox("Am-Ti");
	private JCheckBox bteCheck = new JCheckBox("BTE");
	private JLabel ghHardLabel = new JLabel("GH-Hard");
	private JCheckBox iteCheck = new JCheckBox("ITE");
	private JCheckBox stHardCheck = new JCheckBox("ST");
	private JCheckBox triHardCheck = new JCheckBox("TRI-COE");
	private JLabel ghSoftLabel = new JLabel("GH-Soft");
	private JCheckBox stSoftCheck = new JCheckBox("ST");
	private JCheckBox triSoftCheck = new JCheckBox("TRI-COE");

	private JLabel hearingAidsLabel = new JLabel("Hearing Aids");
	private JLabel haLabel = new JLabel("HA");
	String[] haOptions = { "None", "AIR-BTE", "BTE", "BTE P", "CIC", "CROS", "Interon", "ITC", "ITE", "Jazz-COE",
			"Oticon", "Phonak", "Viatone" };
	private JComboBox<String> haComboBox = new JComboBox<String>(haOptions);
	private JLabel coLabel = new JLabel("CO");
	private JCheckBox coCheckBox = new JCheckBox("TCI-C");

	private JLabel combinedInstrumentLabel = new JLabel("Combined Instruments");
	private JLabel coComboLabel = new JLabel("CO");
	String[] coOptions = { "None", "BTE", "TCI-C", "TCI-COE" };
	private JComboBox<String> coComboBox = new JComboBox<String>(coOptions);

	private JLabel audiologyTestLabel = new JLabel("Assign Category");
	private JTextField categoryField = new JTextField("Treatment Category");
	private JTextField protocolField = new JTextField("Treatment Protocol");

	private JPanel centerPanel = new JPanel();

	private JPanel rightPanel = new JPanel();
	private JLabel realEarMeasurmentsLabel = new JLabel("Real-Ear Measurments");
	private String[] leftEarMeasurments = { "Select Left Ear Mesurment", "Freq LE", "TH L SPL", "Mix L SPL", "Mix L SL",
			"Tol L SPL", "Tol L SL", "Max L SPL", "Max L SL" };
	private JComboBox<String> leftEarCombo = new JComboBox<String>(leftEarMeasurments);
	private JTextField leftEarMeasurementField = new JTextField("Left Ear Measurement");
	private String[] rightEarMeasurments = { "Select Right Ear Mesurment", "Freq RE", "TH R SPL", "Mix R SPL",
			"Mix R SL", "Tol R SPL", "Tol R SL", "Max R SPL", "Max R SL" };
	private JComboBox<String> rightEarCombo = new JComboBox<String>(rightEarMeasurments);
	private JTextField rightEarMeasurementField = new JTextField("Right Ear Measurement");

	private JLabel dateLabel = new JLabel("Date");
	private JTextField dateField = new JTextField("Visit Date");
	private JLabel nextDateLabel = new JLabel("Next Visit Date");
	private JTextField nextDateField = new JTextField("Next Visit Date");

	private JPanel bottomPanel = new JPanel();
	private JLabel medicalNotesLabel = new JLabel("Counselling");
	private JTextArea medicalNotes = new JTextArea("Enter Counseling notes");
	private JButton saveBtn = new JButton("Save");
	private JButton cancelBtn = new JButton("Cancel");
	
	
	public AddVisitView() {
		// TODO Auto-generated constructor stub
		super();
		newVisitPanel = new JPanel();
		newVisitPanel.setLayout(new BorderLayout());

		addNorthPanel();
		addLeftPanel();
		addCenterPanel();
		addRightPanel();
		addBottomPanel();
		this.add(newVisitPanel);
	}

	private void addNorthPanel() {
		titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
		northPanel.setPreferredSize(new Dimension(1000, 50));
		northPanel.setLayout(new BorderLayout());
		northPanel.add(titleLabel, BorderLayout.WEST);
		newVisitPanel.add(northPanel, BorderLayout.NORTH);
	}

	private void addLeftPanel() {
		leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.PAGE_AXIS));
		leftPanel.setPreferredSize(new Dimension(450, 350));

		// Adds Sound generator Components
		leftPanel.add(soundGeneratorLabel);
		soundGeneratorLabel.setFont(new Font("Serif", Font.BOLD, 16));
		JPanel sgPanel = new JPanel();
		sgPanel.setLayout(new BorderLayout());

		JPanel viennatonePane = new JPanel();
		viennatonePane.setLayout(new BoxLayout(viennatonePane, BoxLayout.PAGE_AXIS));
		viennatonePane.setPreferredSize(new Dimension(175, 175));
		viennatonePane.add(viennatoneLabel);
		viennatonePane.add(amtiCheck);
		viennatonePane.add(bteCheck);
		sgPanel.add(viennatonePane, BorderLayout.WEST);

		JPanel ghHardPane = new JPanel();
		ghHardPane.setLayout(new BoxLayout(ghHardPane, BoxLayout.PAGE_AXIS));
		ghHardPane.setPreferredSize(new Dimension(175, 175));
		ghHardPane.add(ghHardLabel);
		ghHardPane.add(iteCheck);
		ghHardPane.add(stHardCheck);
		ghHardPane.add(triHardCheck);
		sgPanel.add(ghHardPane, BorderLayout.CENTER);

		JPanel ghSoftPane = new JPanel();
		ghSoftPane.setLayout(new BoxLayout(ghSoftPane, BoxLayout.PAGE_AXIS));
		ghSoftPane.add(ghSoftLabel);
		ghSoftPane.add(stSoftCheck);
		ghSoftPane.add(triSoftCheck);
		sgPanel.add(ghSoftPane, BorderLayout.EAST);

		leftPanel.add(sgPanel);

		// Adds Hearing Aid Components
		leftPanel.add(hearingAidsLabel);
		hearingAidsLabel.setFont(new Font("Serif", Font.BOLD, 16));
		JPanel hearingAidPanel = new JPanel();
		hearingAidPanel.setLayout(new BorderLayout());

		JPanel haPanel = new JPanel();
		haPanel.setLayout(new BoxLayout(haPanel, BoxLayout.PAGE_AXIS));
		haPanel.add(haLabel);
		haPanel.add(haComboBox);

		JPanel coPanel = new JPanel();
		coPanel.setLayout(new BoxLayout(coPanel, BoxLayout.PAGE_AXIS));
		coPanel.add(coLabel);
		coPanel.add(coCheckBox);

		hearingAidPanel.add(haPanel, BorderLayout.WEST);
		hearingAidPanel.add(coPanel, BorderLayout.EAST);

		leftPanel.add(hearingAidPanel);
		newVisitPanel.add(leftPanel, BorderLayout.WEST);

		// Add Combined Instrument Components
		leftPanel.add(combinedInstrumentLabel);
		combinedInstrumentLabel.setFont(new Font("Serif", Font.BOLD, 16));
		JPanel combinedInstrumentPanel = new JPanel();
		combinedInstrumentPanel.setLayout(new BorderLayout());

		JPanel ciPanel = new JPanel();
		ciPanel.setLayout(new BoxLayout(ciPanel, BoxLayout.PAGE_AXIS));
		ciPanel.add(coComboLabel);
		ciPanel.add(coComboBox);

		combinedInstrumentPanel.add(ciPanel, BorderLayout.WEST);

		leftPanel.add(combinedInstrumentPanel);
		newVisitPanel.add(leftPanel, BorderLayout.WEST);

		newVisitPanel.add(leftPanel, BorderLayout.WEST);
	}

	private void addCenterPanel() {
		newVisitPanel.add(centerPanel);
		centerPanel.setPreferredSize(new Dimension(100, 350));
	}

	private void addRightPanel() {
		rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.PAGE_AXIS));
		rightPanel.setPreferredSize(new Dimension(450, 350));

		rightPanel.add(realEarMeasurmentsLabel);
		realEarMeasurmentsLabel.setFont(new Font("Serif", Font.BOLD, 16));
		JPanel realEarPane = new JPanel();
		realEarPane.setLayout(new BoxLayout(realEarPane, BoxLayout.PAGE_AXIS));
		realEarPane.add(leftEarCombo);
		realEarPane.add(leftEarMeasurementField);

		realEarPane.add(rightEarCombo); 
		realEarPane.add(rightEarMeasurementField);
		rightPanel.add(realEarPane);
		 

		rightPanel.add(audiologyTestLabel);
		audiologyTestLabel.setFont(new Font("Serif", Font.BOLD, 16));
		JPanel audiologyTestPanel = new JPanel();
		audiologyTestPanel.setLayout(new BorderLayout());
		audiologyTestPanel.setPreferredSize(new Dimension(450, 30));
		JPanel atPanel = new JPanel();
		atPanel.setLayout(new BorderLayout());
		categoryField.setPreferredSize(new Dimension(225, 30));
		protocolField.setPreferredSize(new Dimension(225, 30));

		atPanel.add(categoryField, BorderLayout.WEST);
		atPanel.add(protocolField, BorderLayout.EAST);
		audiologyTestPanel.add(atPanel, BorderLayout.WEST);

		rightPanel.add(audiologyTestPanel);
		
		
		dateLabel.setFont(new Font("Serif", Font.BOLD, 16));
		rightPanel.add(dateLabel);
		rightPanel.add(dateField);

		nextDateLabel.setFont(new Font("Serif", Font.BOLD, 16));
		rightPanel.add(nextDateLabel);
		rightPanel.add(nextDateField);

		newVisitPanel.add(rightPanel, BorderLayout.EAST);

	}

	private void addBottomPanel() {
		bottomPanel.setLayout(new BorderLayout());
		bottomPanel.setPreferredSize(new Dimension(1000, 300));
		bottomPanel.add(medicalNotesLabel, BorderLayout.NORTH);
		JScrollPane medNotesScrollPane = new JScrollPane(medicalNotes);
		bottomPanel.add(medNotesScrollPane, BorderLayout.CENTER);

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		buttonPanel.add(saveBtn);
		buttonPanel.add(cancelBtn);

		bottomPanel.add(buttonPanel, BorderLayout.SOUTH);

		newVisitPanel.add(bottomPanel, BorderLayout.SOUTH);
	}
	
	//Sets All Values 
	public void refreshView() {
		amtiCheck.setSelected(false);
		bteCheck.setSelected(false);
		iteCheck.setSelected(false);
		stHardCheck.setSelected(false);
		triHardCheck.setSelected(false);
		stSoftCheck.setSelected(false);
		triSoftCheck.setSelected(false);
		coCheckBox.setSelected(false);
		
		haComboBox.setSelectedIndex(0);
		coComboBox.setSelectedIndex(0);
		leftEarCombo.setSelectedIndex(0);
		rightEarCombo.setSelectedIndex(0);


		categoryField.setText("Treatment Category");
		protocolField.setText("Treatment Protocol");
		leftEarMeasurementField.setText("Left Ear Measurement");
		rightEarMeasurementField.setText("Right Ear Measurement");
		dateField.setText("Visit Date");
		nextDateField.setText("Next Visit Date");
		medicalNotes.setText("Enter Counseling notes");
	}
	
	
	public void addVisitSaveListener(ActionListener listenForSaveBtn) {
		saveBtn.addActionListener(listenForSaveBtn);
	}

	public void addVisitCancelListener(ActionListener listenForCancelBtn) {
		cancelBtn.addActionListener(listenForCancelBtn);
	}
	
	//Title Setter
	public void setTitleLabel(String title) {
		this.titleLabel.setText(title);
	}
	
	/*
	 * Getters
	 */
	public String getDateField() {
		return dateField.getText();
	}

	public String getNextDateField() {
		return nextDateField.getText();
	}

	public String getMedicalNotes() {
		return medicalNotes.getText();
	}

	public String getHaComboBox() {
		return (String) haComboBox.getSelectedItem();
	}
	
	public String getCIComboBox() {
		return (String) coComboBox.getSelectedItem();
	}

	public String getLeftEarCombo() {
		return (String) leftEarCombo.getSelectedItem();
	}

	public String getRightEarCombo() {
		return (String) rightEarCombo.getSelectedItem();
	}

	public boolean getAmtiCheck() {
		return amtiCheck.isSelected();
	}

	public boolean getBteCheck() {
		return bteCheck.isSelected();
	}

	public boolean getIteHardCheck() {
		return iteCheck.isSelected();
	}

	public boolean getStHardCheck() {
		return stHardCheck.isSelected();
	}

	public boolean getTriHardCheck() {
		return triHardCheck.isSelected();
	}

	public boolean getStSoftCheck() {
		return stSoftCheck.isSelected();
	}

	public boolean getTriSoftCheck() {
		return triSoftCheck.isSelected();
	}

	public boolean getCoCheckBox() {
		return coCheckBox.isSelected();
	}
	
	public String getLeftMeasurementField() {
		return leftEarMeasurementField.getText();
	}
	
	public String getRightMeasurmentField() {
		return rightEarMeasurementField.getText();
	}
	
	public String getCategoryField() {
		return categoryField.getText();
	}

	public String getProtocolField() {
		return protocolField.getText();
	}


}
