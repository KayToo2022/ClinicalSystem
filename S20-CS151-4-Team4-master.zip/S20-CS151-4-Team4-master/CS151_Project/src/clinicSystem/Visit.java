package clinicSystem;

/**
 * A class representing a single visit made by a patient
 * 
 * @author ktu20
 *
 */
public class Visit {
	Patient owner;
	
	private int visitNum;

	private boolean viennatoneAmTi;
	private boolean viennatoneBte;
	private boolean hardIte;
	private boolean hardSt;
	private boolean hardTriCoe;
	private boolean softSt;
	private boolean softTriCoe;
	private boolean coTciC;
	
	private String ha;
	private String co;
	private String leftEarMeasurment;
	private String leftEarMeasurmentField;
	private String rightEarMeasurment;
	private String rightEarMeasurmentField;
	private String category;
	private String protocol;
	private String date;
	private String nextDate;
	private String counsellingNotes;

	Visit(){
		super();
	}
	
	Visit(Patient owner){
		this.owner = owner;
		owner.addVisit(this);
		//this.visitNum = owner.getNumVisits();
	}
	
	public String[] getInfo() {
		String coHa = "";
		if(coTciC) {coHa += " CO: TCI-C";}
		String[] visitInfo = {String.valueOf(this.visitNum), this.date, soundGeneratorInfo(), "HA: " + ha + coHa,
				co, "Left: " + leftEarMeasurment + " " + leftEarMeasurmentField 
				+ "Right: " + rightEarMeasurment + " " + rightEarMeasurmentField};
		return visitInfo;
	}
	
	public String soundGeneratorInfo() {
		String info = "";
		if(viennatoneAmTi || viennatoneBte) {info += "ViennaTone:" ;}
		if(viennatoneAmTi) {info += "Am-Ti " ;}
		if(viennatoneBte) {info += "BTE " ;} 
		if(hardIte || hardSt || hardTriCoe) { info += " GH-Hard:";}
		if(hardIte) { info += "ITE "; }
		if(hardSt) { info += "ST "; }
		if(hardTriCoe) { info += "Tri-Coe "; }
		if(softSt || softTriCoe) { info += " GH-Soft: ";}
		if(softSt) { info += "  ST";}
		if(softTriCoe) { info += " Tri-Coe";}

		return info;

	}
	
	public void setPatient(Patient p) {
		this.owner = p;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
	
	public int getVisitNum() {
		return this.visitNum;
	}

	public String getDate() {
		return this.date;
	}
	
	public boolean isViennatoneAmTi() {
		return this.viennatoneAmTi;
	}
	
	public void setViennatoneAmTi(boolean viennatoneAmTi) {
		this.viennatoneAmTi = viennatoneAmTi;
	}

	public boolean isViennatoneBte() {
		return this.viennatoneBte;
	}

	public void setViennatoneBte(boolean viennatoneBte) {
	this.viennatoneBte = viennatoneBte;
	}

	public boolean isHardIte() {
		return this.hardIte;
	}

	public void setHardIte(boolean hardIte) {
		this.hardIte = hardIte;
	}

	public boolean isHardSt() {
		return this.hardSt;
	}

	public void setHardSt(boolean hardSt) {
		this.hardSt = hardSt;
	}

	public boolean isHardTriCoe() {
		return this.hardTriCoe;
	}

	public void setHardTriCoe(boolean hardTriCoe) {
		this.hardTriCoe = hardTriCoe;
	}

	public boolean isSoftSt() {
		return this.softSt;
	}

	public void setSoftSt(boolean softSt) {
		this.softSt = softSt;
	}

	public boolean isSoftTriCoe() {
		return this.softTriCoe;
	}

	public void setSoftTriCoe(boolean softTriCoe) {
		this.softTriCoe = softTriCoe;
	}

	public boolean isCoTciC() {
		return this.coTciC;
	}

	public void setCoTciC(boolean coTciC) {
		this.coTciC = coTciC;
	}

	public String getHa() {
		return this.ha;
	}

	public void setHa(String ha) {
		this.ha = ha;
	}

	public String getCo() {
		return this.co;
	}

	public void setCo(String co) {
		this.co = co;
	}

	public String getLeftEarMeasurment() {
		return this.leftEarMeasurment;
	}

	public void setLeftEarMeasurment(String leftEarMeasurment) {
		this.leftEarMeasurment = leftEarMeasurment;
	}

	public String getLeftEarMeasurmentField() {
		return this.leftEarMeasurmentField;
	}

	public void setLeftEarMeasurmentField(String leftEarMeasurmentField) {
		this.leftEarMeasurmentField = leftEarMeasurmentField;
	}

	public String getRightEarMeasurment() {
		return this.rightEarMeasurment;
	}

	public void setRightEarMeasurment(String rightEarMeasurment) {
		this.rightEarMeasurment = rightEarMeasurment;
	}

	public String getRightEarMeasurmentField() {
		return this.rightEarMeasurmentField;
	}
	
	public String getCounsellingNotes() {
		return this.counsellingNotes;
	}
	
	public void setCounsellingNotes(String s) {
		this.counsellingNotes = s;
	}

	public void setRightEarMeasurmentField(String rightEarMeasurmentField) {
		this.rightEarMeasurmentField = rightEarMeasurmentField;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getProtocol() {
		return this.protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getNextDate() {
		return this.nextDate;
	}

	public void setNextDate(String nextDate) {
		this.nextDate = nextDate;
	}

	public void setVisitNum(int visitNum) {
		this.visitNum = visitNum;
	}
	
	
	
}
