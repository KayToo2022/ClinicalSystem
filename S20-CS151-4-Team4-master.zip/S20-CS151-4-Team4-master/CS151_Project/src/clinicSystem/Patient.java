package clinicSystem;

import java.util.ArrayList;

/**
 * A class representing a patient of the clinic.
 * 
 * @author ktu20
 *
 */
public class Patient {
	
	private int tableIndex;	
	private String id;
	private String dateRegistered;
	private String firstName;	
	private String lastName;
	private String dob;	
	private String gender;	
	private String phoneNumber;
	private String streetAddress1;
	private String streetAddress2;
	private String city;
	private String state;
	private String zipCode;
	private String socialSecurity;
	private String insuranceNum;
	private String protocol;
	private String category;
	private String addInfo;
	private String medicalHistory;
	private String treatmentProgress;

	private ArrayList<Visit> listOfVisits;
	
	/**
	 * Constructor for Patient.
	 */
	public Patient() {
		super();
	}
	
	/**
	 * Constructor for Patient.
	 * 
	 * @param fn - first name.
	 * @param ln - last name.
	 */
	public Patient(String fn, String ln) {
		this.firstName = fn;
		this.lastName = ln;
		
		listOfVisits = new ArrayList<Visit>();
	}

	/**
	 * Get visit.
	 * 
	 * @param index - index of the visit.
	 * 
	 * @return visit with index, if not found, return null.
	 */
	public Visit getVisit(int index) {
		for(int i = 0; i < listOfVisits.size(); i++) {
			if(i == index) {
				return listOfVisits.get(i);
			}
		}
		return null;
	}
	
	/**
	 * Replace visit with new visit.
	 * 
	 * @param index - index of visit to be replaced.
	 * @param visit - new visit.
	 */
	public void replaceVisit(int index, Visit visit) {
		for(int i = 0; i < listOfVisits.size(); i++) {
			if(i == index) {
				listOfVisits.add(index, visit);
				listOfVisits.remove(index + 1);
			}
		}
	}

	/**
	 * Returns a description of a patient.
	 * 
	 * @return a description of a patient.
	 */
	public String getDescription() {
		
		
		String description = new String();
		
		description += "\nName: ";
		if (firstName != null) {
			description += firstName + " ";
		}
		if (lastName != null) {
			description += lastName;
		}
		
		description += "\nID: ";
		if (id != null) {
			description += id;
		}
		
		description += "\nDate Registered: ";
		if (dateRegistered != null) {
			description += dateRegistered;
		}
		
		description += "\nPhone Number: ";
		if (phoneNumber != null) {
			description += phoneNumber;
		}
		
		description += "\nSSN Number: ";
		if (socialSecurity != null) {
			description += socialSecurity;
		}
		
		description += "\nInsurance Number: ";
		if (insuranceNum != null) {
			description += insuranceNum;
		}
		
		description += "\nStreet Address #1: ";
		if (streetAddress1 != null) {
			description += streetAddress1;
		}
		
		description += "\nStreet Address #2: ";
		if (streetAddress2 != null) {
			description += streetAddress2;
		}
		
		description += "\nCity: ";
		if (city != null) {
			description += city;
		}
		
		description += "\nPostal/Zip: ";
		if (zipCode != null) {
			description += zipCode;
		}
		
		description += "\nAdditional Information: ";
		if (addInfo != null) {
			description += addInfo;
		}
		
		description += "\nMedical History: ";
		if (medicalHistory != null) {
			description += medicalHistory;
		}
		
		return  description;
	}
	
	/**
	 * Gets visit info.
	 * 
	 * @return table of visit info.
	 */
	public String[][] getVisitsInfo(){
		String visits[][] = new String[listOfVisits.size()][5];
		for(int i = 0; i<listOfVisits.size(); i++) {
			visits[i]  =  listOfVisits.get(i).getInfo();
		}
		return visits;
	}

	/**
	 * Adds visit.
	 * 
	 * @param v - new visit added.
	 */
	public void addVisit(Visit v) {
		listOfVisits.add(v);
	}
	
	/**
	 * Getters for data.
	 * 
	 * @return data value.
	 */
	
	public int getTableIndex() {
		return this.tableIndex;
	}
	
	public ArrayList<Visit> getVisits() {
		return listOfVisits;
	}
	
	public int getNumVisits() {
		return listOfVisits.size();
	}
	
	public String getID() {
		return id;
	}

	public String getDateRegistered() {
		return dateRegistered;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getDob() {
		return dob;
	}

	public String getGender() {
		return gender;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getStreetAddress1() {
		return streetAddress1;
	}

	public String getStreetAddress2() {
		return streetAddress2;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public String getSocialSecurity() {
		return socialSecurity;
	}

	public String getInsuranceNum() {
		return insuranceNum;
	}

	public String getProtocol() {
		return protocol;
	}

	public String getCategory() {
		return category;
	}
	
	public String getAddInfo() {
		return addInfo;
	}

	public String getMedicalHistory() {
		return medicalHistory;
	}

	public String getTreatmentProgress() {
		return treatmentProgress;
	}
	
	public ArrayList<Visit> getListOfVisits(){
		return listOfVisits;
	}
	
	
	/**
	 * Setters for data values.
	 * 
	 * @param T data - replaces this data with new data.
	 */
	
	public void setId(String id) {
		this.id = id;
	}

	public void setDateRegistered(String dateRegistered) {
		this.dateRegistered = dateRegistered;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setStreetAddress1(String streetAddress1) {
		this.streetAddress1 = streetAddress1;
	}

	public void setStreetAddress2(String streetAddress2) {
		this.streetAddress2 = streetAddress2;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public void setSocialSecurity(String socialSecurity) {
		this.socialSecurity = socialSecurity;
	}

	public void setInsuranceNum(String insuranceNum) {
		this.insuranceNum = insuranceNum;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	public void setAddInfo(String addInfo) {
		this.addInfo = addInfo;
	}

	public void setMedicalHistory(String medicalHistory) {
		this.medicalHistory = medicalHistory;
	}

	public void setTreatmentProgress(String treatmentProgress) {
		this.treatmentProgress = treatmentProgress;
	}

	public void setListOfVisits(ArrayList<Visit> listOfVisits) {
		this.listOfVisits = listOfVisits;
	}
	
	public void setTableIndex(int i) {
		this.tableIndex = i;
	}
	
	/**
	 * Converts Patient info to String
	 * 
	 * @return Patient as a String.
	 */
	public String toString() {
		return getDescription();
	}
}
