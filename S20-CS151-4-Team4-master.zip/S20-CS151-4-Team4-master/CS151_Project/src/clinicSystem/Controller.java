package clinicSystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Controller {

	private String currentPatientId;
	private HomeView homeView;
	private NewPatientView newPatientView;
	private EditPatientView editPatientView;
	private AddVisitView addVisitView;
	private EditVisitView editVisitView;
	private ViewPatientView viewPatientView; 
	
	private Model model;
	
	Controller(Model model){
		homeView = new HomeView();
		homeView.setVisible(true);

		newPatientView = new NewPatientView();
		newPatientView.setVisible(false);
		
		viewPatientView = new ViewPatientView();
		viewPatientView.setVisible(false);
		
		editPatientView = new EditPatientView();
		editPatientView.setVisible(false);
		
		addVisitView = new AddVisitView();
		addVisitView.setVisible(false);

		editVisitView = new EditVisitView();
		editVisitView.setVisible(false);

		this.model = model;
		
		this.homeView.newPatientRegisterListener(new RegisterNewPatientBtnListener());
		this.homeView.homeSelectPatientListener(new SelectPatientListener());
		
		this.newPatientView.newPatientCancelListener(new CancelNewPatientListener());
		this.newPatientView.newPatientSaveListener(new SaveNewPatientListener());
		
		this.editPatientView.editPatientCancelListener(new CancelEditPatientListener());
		this.editPatientView.editPatientSaveListener(new SaveEditPatientListener());
		
		this.addVisitView.addVisitCancelListener(new CancelAddVisitListener());
		this.addVisitView.addVisitSaveListener(new SaveAddVisitListener());
		
		this.editVisitView.editVisitCancelListener(new CancelEditVisitListener());
		this.editVisitView.editVisitSaveListener(new SaveEditVisitListener());
		
		this.viewPatientView.viewPatientEditListener(new EditPatientViewPatientListener()); 
		this.viewPatientView.viewPatientHomeListener(new ReturnHomeViewPatientListener());
		this.viewPatientView.viewPatientAddVisitListener(new AddVisitViewPatientListener());
		this.viewPatientView.viewPatientSelectVisitListener(new SelectVisitViewPatientListener());
	}
	
	/**
	 * Hides HomeView and Shows NewPatientView when register new patient button is pressed
	 */
	class RegisterNewPatientBtnListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			newPatientView.setVisible(true);
			homeView.setVisible(false);
		}
	}
	
	/**
	 * Hides Home View, opens view patient view for current patient. 
	 */
	class SelectPatientListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			model.setCurrentPatientIndex(homeView.getSearchBarText());
			currentPatientId = homeView.getSearchBarText();
			model.currentPatient = model.searchPatientID(currentPatientId);
			
			viewPatientView.clearTable();
			
			try {
				viewPatientView.drawTable(model.currentPatient.getVisitsInfo());
			}
			
			catch(Exception exception) {
				homeView.displayErrorMessage("Invalid Input");
			}
			
			finally {
				viewPatientView.setTitleLabel("Patient " + model.currentPatient.getFirstName() + " " + model.currentPatient.getLastName());
				viewPatientView.setID(model.currentPatient.getID());
				viewPatientView.setDOB(model.currentPatient.getDob());
				viewPatientView.setGender(model.currentPatient.getGender());
				viewPatientView.setPhoneNum(model.currentPatient.getPhoneNumber());
				viewPatientView.setAddress(model.currentPatient.getStreetAddress1());
				String cityStateZip = model.currentPatient.getCity() +", "+ model.currentPatient.getState() + " " + model.currentPatient.getZipCode();
				viewPatientView.setCityStateZip(cityStateZip);
				viewPatientView.setSSN(model.currentPatient.getSocialSecurity());
				viewPatientView.setInsurance(model.currentPatient.getInsuranceNum());
				viewPatientView.setCategory(model.currentPatient.getCategory());
				
				homeView.setVisible(false);
				viewPatientView.setVisible(true);
			}
		}
	}
	
	
	/**
	 * Adds a patient to the model, closes newPatientView, and opens home
	 * 
	 */
	class SaveNewPatientListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {			
			model.currentPatient = new Patient(newPatientView.getFirstNameText(), newPatientView.getLastNameText());
			model.currentPatient.setId(newPatientView.getIdField());
			model.currentPatient.setDob(newPatientView.getDobField());
			model.currentPatient.setGender(newPatientView.getGenderField());
			model.currentPatient.setDateRegistered(newPatientView.getDateField());
			model.currentPatient.setPhoneNumber(newPatientView.getPhoneField());
			model.currentPatient.setSocialSecurity(newPatientView.getSsnField());
			model.currentPatient.setInsuranceNum(newPatientView.getInsuranceField());
			model.currentPatient.setStreetAddress1(newPatientView.getAddress1Field());
			model.currentPatient.setStreetAddress2(newPatientView.getAddress2Field());
			model.currentPatient.setCity(newPatientView.getCityField());
			model.currentPatient.setState(newPatientView.getStateField());
			model.currentPatient.setZipCode(newPatientView.getZipField());
			model.currentPatient.setAddInfo(newPatientView.getAddInfoArea());
			model.currentPatient.setMedicalHistory(newPatientView.getMedicalNotes());
			model.currentPatient.setTableIndex(homeView.getTableSize());
			
			String address = model.currentPatient.getStreetAddress1() + " \n" + model.currentPatient.getCity() + ", " +
					model.currentPatient.getState() + model.currentPatient.getZipCode();
			String[] patient = {model.currentPatient.getFirstName() + " " + model.currentPatient.getLastName(), 
					model.currentPatient.getID(), address, model.currentPatient.getDob(), model.currentPatient.getGender()};
			homeView.addPatient(patient);
			

			model.registerNewPatient(model.currentPatient);
			newPatientView.refreshView();
			newPatientView.setVisible(false);
			homeView.setVisible(true);
		}
	}
	
	
	/**
	 * Cancels making new patient. Closes newPatientView, opens homeView
	 *
	 */
	class CancelNewPatientListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			newPatientView.setVisible(false);
			homeView.setVisible(true);
		}
		
	}
	
	/**
	 * Opens EditPatient View for currentPatient
	 */
	class EditPatientViewPatientListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			editPatientView.setFirstNameText(model.currentPatient.getFirstName());
			editPatientView.setLastNameText(model.currentPatient.getLastName());
			editPatientView.setId(model.currentPatient.getID());
			editPatientView.setDateField(model.currentPatient.getDateRegistered());
			editPatientView.setPhoneField(model.currentPatient.getPhoneNumber());
			editPatientView.setSsnField(model.currentPatient.getSocialSecurity());
			editPatientView.setInsuranceField(model.currentPatient.getInsuranceNum());
			editPatientView.setAddress1Field(model.currentPatient.getStreetAddress1());
			editPatientView.setAddress2Field(model.currentPatient.getStreetAddress2());
			editPatientView.setCityField(model.currentPatient.getCity());
			editPatientView.setStateField(model.currentPatient.getState());
			editPatientView.setZipField(model.currentPatient.getZipCode());
			editPatientView.setAddInfoArea(model.currentPatient.getAddInfo());
			editPatientView.setMedicalNotes(model.currentPatient.getMedicalHistory());
			
			editPatientView.setVisible(true);
			viewPatientView.setVisible(false);
		}
	}
	
	/**
	 * Returns ViewPatientView to home when home btn is pressed
	 */
	class ReturnHomeViewPatientListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			viewPatientView.setVisible(false);
			homeView.setVisible(true);
		}
	}
	
	/**
	 * Opens AddVisitView, Closes ViewPatientView
	 */
	class AddVisitViewPatientListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			addVisitView.refreshView();
			addVisitView.setVisible(true);
			viewPatientView.setVisible(false);
		}
	}
	
	/**
	 * Saves the patients edits, closes editPatientView and opens viewPatientView
	 */
	class SaveEditPatientListener implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {

			model.currentPatient.setFirstName(editPatientView.getFirstNameText());
			model.currentPatient.setLastName(editPatientView.getLastNameText());
			model.currentPatient.setDob(editPatientView.getDobField());
			model.currentPatient.setGender(editPatientView.getGenderField());
			model.currentPatient.setDateRegistered(editPatientView.getDateField());
			model.currentPatient.setPhoneNumber(editPatientView.getPhoneField());
			model.currentPatient.setSocialSecurity(editPatientView.getSsnField());
			model.currentPatient.setInsuranceNum(editPatientView.getInsuranceField());
			model.currentPatient.setStreetAddress1(editPatientView.getAddress1Field());
			model.currentPatient.setStreetAddress2(editPatientView.getAddress2Field());
			model.currentPatient.setCity(editPatientView.getCityField());
			model.currentPatient.setState(editPatientView.getStateField());
			model.currentPatient.setZipCode(editPatientView.getZipField());
			model.currentPatient.setAddInfo(editPatientView.getAddInfoArea());
			model.currentPatient.setMedicalHistory(editPatientView.getMedicalNotes());
			
			viewPatientView.setTitleLabel("Patient " + model.currentPatient.getFirstName() + " " + model.currentPatient.getLastName());
			viewPatientView.setID(model.currentPatient.getID());
			viewPatientView.setDOB(model.currentPatient.getDob());
			viewPatientView.setGender(model.currentPatient.getGender());
			viewPatientView.setPhoneNum(model.currentPatient.getPhoneNumber());
			viewPatientView.setAddress(model.currentPatient.getStreetAddress1());
			String cityStateZip = model.currentPatient.getCity() +", "+ model.currentPatient.getState() + " " + model.currentPatient.getZipCode();
			viewPatientView.setCityStateZip(cityStateZip);
			viewPatientView.setSSN(model.currentPatient.getSocialSecurity());
			viewPatientView.setInsurance(model.currentPatient.getInsuranceNum());
			viewPatientView.setCategory(model.currentPatient.getCategory());
			
			String address = model.currentPatient.getStreetAddress1() + " \n" + model.currentPatient.getCity() + ", " +
					model.currentPatient.getState() + model.currentPatient.getZipCode();
			String[] patient = {model.currentPatient.getFirstName() + " " + model.currentPatient.getLastName(), 
					model.currentPatient.getID(), address, model.currentPatient.getDob(), model.currentPatient.getGender()};
			homeView.updatePatient(patient, model.currentPatient.getTableIndex());
			
			editPatientView.setVisible(false);
			viewPatientView.setVisible(true);
		}
	}
	
	/**
	 * Closes Edit Patient View, and opens ViewPatientView
	 */
	class CancelEditPatientListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			editPatientView.setVisible(false);
			viewPatientView.setVisible(true);
		}
	}
	
	/**
	 * Adds a visit to current patient, updated table, Closes addVisitView, Opens View Patient view
	 */
	class SaveAddVisitListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			String category = "Treament: " + addVisitView.getCategoryField() + ", Protocol: " + addVisitView.getProtocolField();
			model.currentPatient.setCategory(category);
			viewPatientView.setCategory(model.currentPatient.getCategory());
			
			model.currentVisit = new Visit();
			model.currentVisit.setViennatoneAmTi(addVisitView.getAmtiCheck());
			model.currentVisit.setViennatoneBte(addVisitView.getBteCheck());
			model.currentVisit.setHardIte(addVisitView.getIteHardCheck());
			model.currentVisit.setHardSt(addVisitView.getStHardCheck());
			model.currentVisit.setHardTriCoe(addVisitView.getTriHardCheck());
			model.currentVisit.setSoftSt(addVisitView.getStSoftCheck());
			model.currentVisit.setSoftTriCoe(addVisitView.getTriSoftCheck());
			model.currentVisit.setCoTciC(addVisitView.getCoCheckBox());
			model.currentVisit.setHa(addVisitView.getHaComboBox());
			model.currentVisit.setCo(addVisitView.getCIComboBox());
			model.currentVisit.setLeftEarMeasurment(addVisitView.getLeftEarCombo());
			model.currentVisit.setRightEarMeasurment(addVisitView.getRightEarCombo());
			model.currentVisit.setLeftEarMeasurmentField(addVisitView.getLeftMeasurementField());
			model.currentVisit.setRightEarMeasurmentField(addVisitView.getRightMeasurmentField());
			model.currentVisit.setCategory(addVisitView.getCategoryField());
			model.currentVisit.setProtocol(addVisitView.getProtocolField());
			model.currentVisit.setDate(addVisitView.getDateField());
			model.currentVisit.setNextDate(addVisitView.getNextDateField());
			model.currentVisit.setCounsellingNotes(addVisitView.getMedicalNotes());
			model.currentVisit.setVisitNum(model.currentPatient.getNumVisits());
			
			model.currentPatient.addVisit(model.currentVisit);
			
			viewPatientView.clearTable();
			viewPatientView.drawTable(model.currentPatient.getVisitsInfo());
			
			addVisitView.setVisible(false);
			viewPatientView.setVisible(true);
		}
	}
	
	/**
	 * Closes Add Visit View, and opens ViewPatientView
	 */
	class CancelAddVisitListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			addVisitView.setVisible(false);
			viewPatientView.setVisible(true);
		}
	}
	
	/**
	 * Selects a visit, opens edit visit view, closes view patient view
	 */
	class SelectVisitViewPatientListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			try {
				model.currentVisit = model.currentPatient.getVisit(viewPatientView.getSearchBarField());
				
			}
			catch(NullPointerException exception) {
				editVisitView.displayErrorMessage("Invalid Input");
			}
			finally{
				editVisitView.setAmtiCheck(model.currentVisit.isViennatoneAmTi());
				editVisitView.setBteCheck(model.currentVisit.isViennatoneBte());
				editVisitView.setIteHardCheck(model.currentVisit.isHardIte());
				editVisitView.setStHardCheck(model.currentVisit.isHardSt());
				editVisitView.setTriHardCheck(model.currentVisit.isHardTriCoe());
				editVisitView.setStSoftCheck(model.currentVisit.isSoftSt());
				editVisitView.setTriSoftCheck(model.currentVisit.isSoftTriCoe());
				editVisitView.setHaComboBox(model.currentVisit.getHa());
				editVisitView.setHaCoCheckBox(model.currentVisit.isCoTciC());
				editVisitView.setCoComboBox(model.currentVisit.getCo());
				editVisitView.setLeftEarCombo(model.currentVisit.getLeftEarMeasurment());
				editVisitView.setLeftEarMeasurementField(model.currentVisit.getLeftEarMeasurment());
				editVisitView.setRightEarCombo(model.currentVisit.getRightEarMeasurment());
				editVisitView.setRightEarMeasurementField(model.currentVisit.getRightEarMeasurment());
				editVisitView.setCategory(model.currentVisit.getCategory());
				editVisitView.setProtocol(model.currentVisit.getProtocol());
				editVisitView.setDate(model.currentVisit.getDate());
				editVisitView.setNextDate(model.currentVisit.getNextDate());
				
				editVisitView.setVisible(true);
				viewPatientView.setVisible(false);
			}
		}
	}
	
	/**
	 * Saves edited visit to model. Closes Edit Patient View, and opens ViewPatientView
	 */
	class SaveEditVisitListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			model.currentVisit.setViennatoneAmTi(editVisitView.getAmtiCheck());
			model.currentVisit.setViennatoneBte(editVisitView.getBteCheck());
			model.currentVisit.setHardIte(editVisitView.getIteHardCheck());
			model.currentVisit.setHardSt(editVisitView.getStHardCheck());
			model.currentVisit.setHardTriCoe(editVisitView.getTriHardCheck());
			model.currentVisit.setSoftSt(editVisitView.getStSoftCheck());
			model.currentVisit.setSoftTriCoe(editVisitView.getTriSoftCheck());
			model.currentVisit.setCoTciC(editVisitView.getHaCoCheckBox());
			model.currentVisit.setHa(editVisitView.getHaComboBox());
			model.currentVisit.setCo(editVisitView.getCoComboBox());
			model.currentVisit.setLeftEarMeasurment(editVisitView.getLeftEarCombo());
			model.currentVisit.setRightEarMeasurment(editVisitView.getRightEarCombo());
			model.currentVisit.setLeftEarMeasurmentField(editVisitView.getLeftEarMeasurementField());
			model.currentVisit.setRightEarMeasurmentField(editVisitView.getRightEarMeasurementField());
			model.currentVisit.setCategory(editVisitView.getCategory());
			model.currentVisit.setProtocol(editVisitView.getProtocol());
			model.currentVisit.setDate(editVisitView.getDate());
			model.currentVisit.setNextDate(editVisitView.getNextDate());
			model.currentVisit.setCounsellingNotes(editVisitView.getMedicalNotes());
			
			model.currentPatient.replaceVisit(model.currentVisit.getVisitNum(), model.currentVisit);
			
			viewPatientView.clearTable();
			viewPatientView.drawTable(model.currentPatient.getVisitsInfo());
			
			editVisitView.setVisible(false);
			viewPatientView.setVisible(true);
		}
	}
	
	/**
	 * Closes Edit Visit View, and opens ViewPatientView
	 */
	class CancelEditVisitListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			editVisitView.setVisible(false);
			viewPatientView.setVisible(true);
		}
	}
	
	public void setCurrentId(String id) {
		currentPatientId = id;
	}
}